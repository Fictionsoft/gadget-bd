
<?php get_header(); ?>       
	
    <div class="container">
        <div class="content_404">
        <h2>404 Not Found</h2>
        <h3>May Be You Looking For Something Else</h3>
        <p>You may Visit The <a href="<?php esc_url(bloginfo('home'))?>">Home Page</a><p>

            
        </div>                
    </div> 

                
<?php get_footer(); ?>