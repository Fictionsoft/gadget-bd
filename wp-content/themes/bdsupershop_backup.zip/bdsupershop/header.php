<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset') ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">        
        <meta name="description" content="<?php bloginfo('description'); ?>"/>
        <meta name="robots" content="index,follow"/>
       
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
    	<div class="header" id="header-fix">
        	<div class="header_top">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-2">
                            <div class="logo">
                                <a href="<?php echo get_home_url(); ?>"><img src="<?php echo get_theme_mod( 'site_logo' ); ?>"></a><!--<img src="<?php /* echo get_stylesheet_directory_uri(); */?>/images/logo.png" ></a>-->
                            </div>
                        </div>

                        <div class="col-sm-4 div_overflow">
                            <div class="search_section">
                                <?php dynamic_sidebar('header-search') ?>
                            </div>
                        </div>

                        <div class="col-sm-3 removing_padding">
                            <div class="registration_section">
                                <div class="registration">

                                        <?php
                                            $current_user = wp_get_current_user();
                                            if ( 0 == $current_user->ID ) {
                                                // Not logged in.
                                                echo('<p> Welcome visitor you can <a href="'. get_site_url(null, 'login', null). '">Login</a>  <a href=""></a>  </p>');
                                            } else {
                                                // Logged in.
                                                echo('<p class="fs_login_welcome_message"> Welcome <b>'. $current_user->first_name." ". $current_user-> last_name .'</b> <a href="'. get_site_url(null, 'my-account/customer-logout/', null). '">Logout</a> </p>');

                                            }
                                        ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-1 removing_padding">
                            <div class="cart_count">
                                <p><a class="cart-contents" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>"><img src="http://fictionsoft.com/demo/efair/images/home/i_mycart.png"></a> CART</p>
                            </div>
                        </div>

                        <div class="col-sm-2 removing_padding">
                            <div class="call">
                                <img src="<?php echo get_template_directory_uri() ?>/images/call.png"> 01750-800764
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="header_bottom">
                <div class="container">

                    <div class="main_nav">
                        <div class="navbar_header" id="show_mobile_btn">
                            <i class="fa fa-bars"></i>
                        </div>

                        <div class="main_menu">
                            <?php wp_nav_menu(array(
                                'theme_location' => 'main-menu',
                                'container' => false,
                            ));
                            ?>
                        </div><!-- /.navbar-collapse -->
                    </div>
                </div>
            </div>

            <!--    <h4> Product categories </h4>-->
            <?php require_once('inc/hover_all_cat.php') ?>
        </div>


